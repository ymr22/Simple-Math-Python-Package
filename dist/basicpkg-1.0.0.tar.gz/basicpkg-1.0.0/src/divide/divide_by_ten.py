def divide_by_ten(num):
    return num / 10