# `basicpkg`

The `basicpkg` is a simple testing example to understand the basics of developing your first Python package.

from multiply.by_ten import multiply_by_ten
from divide.by_ten import divide_by_ten

multiply_by_ten(9)
divide_by_ten(210)