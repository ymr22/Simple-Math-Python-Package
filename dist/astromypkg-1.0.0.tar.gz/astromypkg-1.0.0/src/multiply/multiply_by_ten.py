def multiply_by_ten(num):
    return num * 10